//
//  ImageController.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 21/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//

import UIKit

class ImageController: UIViewController{
    
}
