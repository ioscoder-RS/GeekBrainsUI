//
//  CustomWeatherLayout.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 17/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//
import UIKit

class WeatherCollectionViewLayout: UICollectionViewLayout {

}
