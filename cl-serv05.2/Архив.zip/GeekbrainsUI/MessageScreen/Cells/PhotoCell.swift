//
//  PhotoCell.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 16/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//

import UIKit

class PhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var cellUsername: UILabel!
  /*
    var imageClicked: ((UIView)->())? = nil
    
    override func awakeFromNib() {
        photo.isUserInteractionEnabled = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(pickImage))
        addGestureRecognizer(tapGesture)
    }

    @objc func pickImage(){
        imageClicked?(photo)
    }
 */
}
