//
//  LoadIndicators.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 23/01/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import UIKit

class LoadIndicators {
    

    
    //MARK: здесь будет функция, выводящая индикатор
    //функция выводит три мигающих круга
    
    //    @IBOutlet weak var animationCircle1: UIImageView!
    //    @IBOutlet weak var animationCircle2: UIImageView!
    //    @IBOutlet weak var animationCircle3: UIImageView!
     //   @IBOutlet weak var animationLabel1: UILabel!
    
    func animationLoad(duration: Double){
        //        
        //        //animationLabel1.isHidden = false
        //        animationCircle1.isHidden = false
        //        
        //        UIView.animate( withDuration: duration/5,
        //                        delay: 0.0,
        //                        options: [.repeat,.autoreverse],
        //                        animations:{ self.animationCircle1.alpha = 0.3},
        //                        completion: { _ in  UIView.animate( withDuration: duration/5,
        //                                                            delay: 0.0,
        //                                                            options: [],
        //                                                            animations:{ self.animationCircle1.alpha = 1; self.animationCircle1.isHidden = true}) })
        //        
        //        animationCircle2.isHidden = false
        //        UIView.animate( withDuration: duration/5,
        //                        delay: 1.0,
        //                        options: [.repeat,.autoreverse],
        //                        animations:{ self.animationCircle2.alpha = 0.3},
        //                        completion: { _ in  UIView.animate( withDuration: duration/5,
        //                                                            delay: 0.0,
        //                                                            options: [],
        //                                                            animations:{ self.animationCircle2.alpha = 1; self.animationCircle2.isHidden = true}) })
        //        
        //        animationCircle3.isHidden = false
        //        UIView.animate( withDuration: duration/5,
        //                        delay: 2.0,
        //                        options: [.repeat,.autoreverse],
        //                        animations:{ self.animationCircle3.alpha = 0.3},
        //                        completion: { _ in  UIView.animate( withDuration: duration/5,
        //                                                            delay: 0.0,
        //                                                            options: [],
        //                                                            animations:{ self.animationCircle3.alpha = 1; self.animationCircle3.isHidden = true}) })
        //        
        //        animationLabel1.isHidden = true
        //        
        //        /*
        //         //делаем кнопку недоступной пока идет снег (= duration)
        //         self.toGroup.isEnabled = false
        //         DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
        //         self.snowButton.isEnabled = true
        //         }
        //         */
    }
}// class LoadIndicators
