//
//  VKWorkWithDBRealm.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 22/01/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import Foundation
import RealmSwift

enum VKObjects{
    case VKUser
    case VKGroup
    case VKPhoto
}


