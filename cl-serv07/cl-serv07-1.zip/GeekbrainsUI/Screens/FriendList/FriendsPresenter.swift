//
//  FriendsPresenter.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 29/01/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import Foundation
import RealmSwift

protocol FriendsPresenter{
    //   typealias Out = Swift.Result
    
    func viewDidLoad()
    func searchFriends(name: String)
    
    func numberOfSections() -> Int
    func numberOfRowsInSection(section: Int) -> Int
    func getSectionIndexTitles() -> [String]?
    func getModelAtIndex(indexPath: IndexPath) -> VKUserRealm?
    func getTitleForSection(section: Int) -> String?
    
}

struct SectionRealm<T: RealmCollectionValue>{
    var title: String
    var items: Results<T>
}

class FriendsPresenterImplementation : FriendsPresenter {
    var friends = [Friend]()
    
    private var vkAPI: VKAPi
    private var database: FriendsSource
    
    //mvc
    private var sortedFriendsResults = [Section<VKUserRealm>]()
    private var friendsResult: Results<VKUserRealm>!
    
    private weak var view:FriendsListView?

    init (database: FriendsSource, view: FriendsListView) {
        vkAPI = VKAPi()
        self.database = database
        self.view = view
    }
    
    func viewDidLoad() {
       
        getFriendsFromDatabase()
             getFriendsFromApi()
    }
    
    func getFriendsFromDatabase(){
        do {
            self.friendsResult = try database.getAllUsers()
            self.makeSortedSections()
            self.view?.updateTable()
        }catch { print(error)}
    }//func getFriendsFromDatabase()
    
    func getFriendsFromApi(){
        //Получаем пользователей из Web
        vkAPI.getFriendList(token: Session.shared.token){  result in
            switch result {
            case .success(let webUsers): //массив VKUser из Web
                do{
                    self.database.addUsers(users: webUsers)
                    self.getFriendsFromDatabase()
      
                }catch {
                    print("we got error in database.getAllUsers(): \(error)")
                }
            case .failure(let error):
                print("we got error in getFriendsFromApi(): \(error)")
            }//switch
        }//completion
    }//func getFriendsFromApi()
    
    func searchFriends(name: String) {
         do {
            //TODO
         }catch {
             print(error)
         }
     }
    

    
    private func makeSortedSections(){
        let groupedFriends = Dictionary.init(grouping: friendsResult){$0.lastName.prefix(1) }
        sortedFriendsResults = groupedFriends.map { Section(title: String($0.key), items: $0.value) }
        sortedFriendsResults.sort {$0.title < $1.title}
    }// func makeSortedSections()
    
}//class

extension FriendsPresenterImplementation {
    func numberOfRowsInSection(section: Int) -> Int {
        return sortedFriendsResults[section].items.count
    }
    
    func getModelAtIndex(indexPath: IndexPath) -> VKUserRealm? {
        return sortedFriendsResults[indexPath.section].items[indexPath.row]
    }
    
    func numberOfSections() -> Int {
        return sortedFriendsResults.count
    }
    
    func getSectionIndexTitles() -> [String]? {
            return sortedFriendsResults.map{$0.title}
    }
    
    func getTitleForSection(section: Int) -> String? {
        return sortedFriendsResults[section].title
    }
    
  
}
