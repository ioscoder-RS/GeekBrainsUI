//
//  GroupCell.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 03/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//

import UIKit

class GroupCell: UITableViewCell {

    @IBOutlet weak var groupname:UILabel!
    @IBOutlet weak var groupimage: UIImageView!
}

class NewGroupCell: UITableViewCell {

    @IBOutlet weak var newgroupname:UILabel!
 
}
