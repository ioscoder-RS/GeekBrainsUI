import UIKit

class FriendCell : UITableViewCell {
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var userimage: UIImageView!
    @IBOutlet weak var myShadowView: CircleShadowImage!
}
