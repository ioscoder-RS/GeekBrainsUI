//
//  ThreeCirclesViewController.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 27/01/2020.
//  Copyright © 2020 raskin-sa. All rights reserved.
//

import UIKit

class ThreeCirclesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var animationCirlce1: UIImageView!
    @IBOutlet weak var animationCircle2: UIImageView!
    @IBOutlet weak var animationCirlce3: UIImageView!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
