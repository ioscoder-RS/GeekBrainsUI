//
//  NewGroupList.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 03/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//

import UIKit

class NewGroupList: UITableViewController {
    
    var lv_newgrouplist = ["NewGroup1", "NewGroup2"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return lv_newgrouplist.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewGroupTemplate", for: indexPath) as! NewGroupCell
        
        var ls_indexrow:String?
        
        ls_indexrow = lv_newgrouplist[indexPath.row]
        
        cell.newgroupname.text = ls_indexrow!
        
        return cell
    }
    
}
