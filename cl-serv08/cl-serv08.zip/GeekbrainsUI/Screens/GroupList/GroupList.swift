//
//  GroupList.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 03/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//



import UIKit
import RealmSwift

protocol CellImageTapDelegate {
    func tableCell(didClickedImageOf tableCell: GroupCell)
}

class GroupList: UITableViewController, CellImageTapDelegate/*, ImageViewPresenterSource*/ {
    
    // var source: UIView?
    var vkAPI = VKAPi()
    var groups = [Group]()
    var presenter = GroupPresenterImplementation()
    var groupDB = GroupRepository()
    var groupRepository = GroupRepository()
    var groupsResult: Results<VKGroupRealm>!
    var token: NotificationToken?
    var tokenUser: NotificationToken?
    
    @IBOutlet weak var groupSearchBar: UISearchBar!
    
    var customRefreshControl = UIRefreshControl()
    var vkApi = VKAPi()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addRefreshControl()
        groupSearchBar.delegate = self //чтобы поиск отрабатывал
        
        //Показ групп, ранее сохраненных в БД
        showGroups()
        
        //запрос групп из интернета
        presenter.getGroupList(){
            result in
            switch result{
            case .success (let groups):
                let a = 1
                //              self.groupsResult = groups
            //              self.tableView.reloadData()
            case .failure (let error):
                print(error)
            }//switch
        }//completion getGroupList
        
    }//viewdidload
    
    deinit {
        token?.invalidate()
    }
    
    func showGroups() {
        //        //Получение групп текущего пользователя
        do{
            groupsResult = try groupDB.getAllGroups()
            //MARK: отслеживание изменений в БД
            token = groupsResult.observe {[weak self] results in
                switch results{
                case .error(let error):
                    print(error)
                case .initial:
                    self?.tableView.reloadData()
                case let .update(_,  deletions, insertions,  modifications):
                    self?.tableView.beginUpdates()
                    self?.tableView.deleteRows(at: deletions.map {IndexPath(row: $0, section: 0)}, with: .none)
                    self?.tableView.insertRows(at: insertions.map {IndexPath(row: $0, section: 0)}, with: .none)
                    self?.tableView.reloadRows(at: modifications.map {IndexPath(row: $0, section: 0)}, with: .none)
                    self?.tableView.endUpdates()
                }// switch results
            }
            
        } catch {
            print(error)
        }
        
    }// func showGroups
    
    func tableCell(didClickedImageOf tableCell: GroupCell) {
        // функция вызывает анимацию сжимающейся иконки
        //из ячейки класса GroupCell, на которую нажали
        tableCell.setAnimation()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return self.groups.count
        self.groupsResult.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "GroupTemplate", for: indexPath) as? GroupCell else{ return UITableViewCell()}
        
        let ls_indexrow = groupsResult[indexPath.row]
        cell.groupname.text = ls_indexrow.groupName
        
        //загружаем изображения с кэшем через библиотеку KingFisher
        let url = URL(string: ls_indexrow.avatarPath)
        cell.groupimage.kf.setImage(with: url)
        cell.delegate = self
        
        return cell
    } // override func tableView(_ tableView: UITableView, cellForRowAt
    
    //запускаем снег по нажатию соответствующей кнопки
    @IBOutlet weak var snowButton: UIBarButtonItem!
    @IBAction func snowButtonPressed(_ sender: Any) {
        let duration = 30.0
        let emitterSnow = EmitterSnow()
        
        emitterSnow.letItSnow(duration: duration, view: view)
        
        //делаем кнопку недоступной пока идет снег (= duration)
        self.snowButton.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            self.snowButton.isEnabled = true
        }
    }
    @IBAction func AddButtonPressed(_ sender: Any) {
        let l_count: Int = groupsResult.count+1
        array_append(name: "NewGroup\(l_count)", id: l_count)
    }
    
    @IBAction func toGroupDetailButtonPressed(_ sender: Any) {
        let animationDuration = 9.0
        //     animationLoad(duration: animationDuration)
        
        self.perform(#selector(navigateToViewController), with: nil, afterDelay: animationDuration)
    }
    
    @objc func navigateToViewController() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(identifier: "MessageViewController") as! MessageViewController
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    func array_append ( name: String, id: Int){
        //        groups.append(Group(groupName: name, avatarPath: "no", id: id))
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell:
        UITableViewCell, forRowAt indexPath: IndexPath) {
        
    }
    
    //Добавляем ф-л удаления строчки через UITableViewCell.EditingStyle
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete{
            //groupsResult.remove(at: indexPath.row)
            tableView.reloadData()
        }
    }
    func array_delete ( row: Int){
        // groups.remove(at: row)
        tableView.reloadData()
    }
    
    func addRefreshControl(){
        customRefreshControl.attributedTitle = NSAttributedString(string:"refreshing...")
        customRefreshControl.addTarget(self, action: #selector(refreshTable), for: .valueChanged)
        tableView.addSubview(customRefreshControl)
    }
    
    @objc func refreshTable(){
        //фейковая функция, имитирует обновление из интернета
        
        //функция DispatchQueue дает паузу в 3 сек...
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            //... и закрывает refreshing
            self.customRefreshControl.endRefreshing()
        }
    }
    
}//class GroupList

extension GroupList: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        do{
            self.groupsResult = searchText.isEmpty ? try groupDB.getAllGroups() : try groupDB.searchGroups(name: searchText)
        }catch {print(error)}
            tableView.reloadData()
    }
        
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        view.endEditing(true)
    }
}




