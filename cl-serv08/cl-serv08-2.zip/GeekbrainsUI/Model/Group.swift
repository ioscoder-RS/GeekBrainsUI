//
//  Group.swift
//  GeekbrainsUI
//
//  Created by raskin-sa on 08/12/2019.
//  Copyright © 2019 raskin-sa. All rights reserved.
//

import Foundation

struct Group{
    var id: Int
    var groupName:String
    var avatarPath:String
 
}

//var myGroup:[Group] = [
//Group(groupName:"Одноклассники", avatarPath:"Group2", id:1),
//Group(groupName:"Семья", avatarPath:"Group1", id:2),
//Group(groupName:"Рязань-2000", avatarPath:"2", id:3),
//Group(groupName:"Любители коров", avatarPath:"3", id:4)
//]





